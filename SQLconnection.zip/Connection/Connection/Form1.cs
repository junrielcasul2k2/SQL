﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Connection
{
	public partial class Form1 : Form
	{
		private OleDbConnection conn;
		private OleDbCommand cmd;
		private OleDbDataAdapter adapter;
		private DataTable dt;
		public Form1()
		{
			InitializeComponent();
		}
 
		void displayTables() 
		{ 
			conn = new OleDbConnection("Provider=Microsoft.ACE.OleDb.16.0; Data Source=" +Application.StartupPath+ "\\database1.accdb");
			dt = new DataTable();
			adapter = new OleDbDataAdapter("SELECT *FROM Table1", conn);
			conn.Open();
			adapter.Fill(dt);	
			dataGridView1.DataSource = dt;
			conn.Close();
 		}
 
		private void Form1_Load(object sender, EventArgs e)
		{
			 displayTables();
		}

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
			string query = "INSERT INTO Table1 (ID,firstname,lastname) VALUES " +
							"(@id,@fname,@lname)";
			cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", textBox3.Text);
            cmd.Parameters.AddWithValue("@fname", textBox1.Text);
            cmd.Parameters.AddWithValue("@lname", textBox2.Text);
            conn.Open();
			cmd.ExecuteNonQuery();
			conn.Close();
			MessageBox.Show("NAME INSERTED :)");
			displayTables();

        }
    }
}
